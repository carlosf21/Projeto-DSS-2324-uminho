package business.SSFuncionarios;

public class Administrativo extends Funcionario {
	public Administrativo(String idFunc, String nome) {
		super(idFunc, nome);
	}
}
