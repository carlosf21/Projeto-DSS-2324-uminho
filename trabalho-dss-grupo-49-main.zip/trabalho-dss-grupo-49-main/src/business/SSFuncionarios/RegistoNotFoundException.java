package business.SSFuncionarios;

public class RegistoNotFoundException extends Exception {
	public RegistoNotFoundException(String msg) {
		super(msg);
	}
}