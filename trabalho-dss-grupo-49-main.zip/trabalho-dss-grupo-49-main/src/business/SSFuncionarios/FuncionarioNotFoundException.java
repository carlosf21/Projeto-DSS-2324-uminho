package business.SSFuncionarios;

public class FuncionarioNotFoundException extends Exception {
	public FuncionarioNotFoundException(String msg) {
		super(msg);
	}
}