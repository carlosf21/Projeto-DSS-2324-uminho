package business.SSClientes;

public class ClienteNotFoundException extends Exception {
	public ClienteNotFoundException(String msg) {
		super(msg);
	}
}