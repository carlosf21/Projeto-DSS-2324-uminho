package business.SSClientes;

public class TipoMotorNotFoundException extends Exception {
	public TipoMotorNotFoundException(String msg) {
		super(msg);
	}
}