package business.SSClientes;

public class VeiculoNotFoundException extends Exception {
	public VeiculoNotFoundException(String msg) {
		super(msg);
	}
}