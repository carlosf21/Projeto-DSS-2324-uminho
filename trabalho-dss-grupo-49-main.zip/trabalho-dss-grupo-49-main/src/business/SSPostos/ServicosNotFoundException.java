package business.SSPostos;

public class ServicosNotFoundException extends Exception {
	public ServicosNotFoundException(String msg) {
		super(msg);
	}
}