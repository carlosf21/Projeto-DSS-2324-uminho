package business.SSPostos;

public class PostoNotFoundException extends Exception {
	public PostoNotFoundException(String msg) {
		super(msg);
	}
}